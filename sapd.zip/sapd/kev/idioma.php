﻿<?php

$Texto_Index_1	= "Tu cuenta";
$Texto_Index_2	= "Tus opciones";
$Texto_Index_3	= "Jugadores Conectados";
$Texto_Index_4	= "Estado de los servidores";
$Texto_Index_5	= "en Facebook";
$Texto_Index_6	= "en Twitter";
$Texto_Index_7	= "Torneo de carreras LV (Posiciones)";
$Texto_Index_8	= "Ver tabla de posiciones";

?>